module.exports.userController = require('./user.controller');
module.exports.donationController = require('./donation.controller');
module.exports.adminController = require('./admin.controller');
module.exports.voucherController = require('./voucher.controller');
module.exports.roomController = require('./room.controller');